                                                                                                                              
     /*const body = document.querySelector("body");
     
        const cars = [
    {
        title: "BMW",
        price: "40000",
        count: "15"

    },
    {
        title: "Toyota",
        price: "20000",
        count: "13"
    },
    {
        title: "Ford",
        price: "30000",
        count: "20"
    },
    {
        title: "Chevrolet",
        price: "60000",
        count: "9"
    },
    {
        title: "Volkswagen",
        price: "30000",
        count: "13"
    },
]

for (let i = 0; i < cars.length; i++) {
    let carlist = document.createElement("ol");

    let title = document.createElement("li");
    title.innerText = cars[i].title;

    let price = document.createElement("li");
    price.innerText = cars[i].price;

    let count = document.createElement("li");
    count.innerText = cars[i].count;

    carlist.append(title,price,count);
    body.append(carlist);
    
}*/


//Таблица


const tableText = [ "No.", "Full Name", "Position","Alary"];


const arr = [
    {

    A: "1",
    B: "Bill Gates",
    C: "Founder Microsoft",
    D: "$1000"
},
{
    A: "2",
    B: "Steve Jobs",
    C: "Founder Apple",
    D: "$1200"

},
{
    A: "3",
    B: "Larry Page",
    C: "Founder Google",
    D: "$1100"
},
{
    A: "4",
    B: "Mark Zuckenberg",
    C: "Founder Facebook",
    D: "$1300"
    

}

]

const div = document.createElement('div');

const table = document.createElement('table');
table.style.borderBlock = "block";
let trHeader = document.createElement('tr');

for(let header of tableText){
    let tr = document.createElement('tr');

tr.style.borderStyle = "solid";
tr.style.borderWidth = "2px";
tr.style.padding = "15ppx";

tr.innerHTML = header;
trHeader.append(tr)

}
table.append(trHeader);


for (let i = 0; i < arr.length; i++) {
    let one = document.createElement('one');

    for (let j = 0; j < 4; j++) {
      let td = document.createElement('td');
      td.innerHTML = arr[i][j];
      td.style.borderWidth = "2px";
      td.style.borderStyle = "solid";
      td.style.padding = "15px";
      one.append(td);
        
    }
    table.append(one);



}
body.append(table);
document.body.append(div)

















